﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.WebSockets;
using MySql;
using MySql.Data.MySqlClient;

namespace miniProject
{
    public partial class _default : System.Web.UI.Page
    {
        public String blood_group;
        public String country;
        public String city;
        public String district;
        public String state;

        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void loginButton_Click(object sender, EventArgs e)
        {
            String username = loginUsername.Text;
            String password = loginPassword.Text;

            String connString = "host=localhost;username=root;password=Bhanu@123;database=exl_db";
            MySqlConnection conn = new MySqlConnection(connString);

            conn.Open();
            String query = $"select * from users where UserId = '{username}';";
            MySqlCommand cmd = new MySqlCommand(query,conn);
            MySqlDataReader row = cmd.ExecuteReader();

            if (row.HasRows)
            {
                while (row.Read())
                {
                    String currPass = row["password"].ToString();
                    if (currPass == password)
                    {
                        Response.Write("<script>alert('User logged in sucesfully!!!');</script>");
                    }
                    else
                    {
                        Response.Write("<script>alert('Username or Password Incorrect !')</script>");
                    }
                }
            }
            conn.Close();
        }

        protected void findDonorButton_Click(object sender, EventArgs e)
        {
            String blood_group = findBloodGroup.Text;
            String city = findCity.Text;
            String country = findCountry.Text;
            String district = findDistrict.Text;
            String state = findState.Text;


            String connString = "host=localhost;username=root;password=Bhanu@123;database=exl_db";
            MySqlConnection conn = new MySqlConnection(connString);
            
            conn.Open(); 
            
            String query = $"select * from users where blood_group='{blood_group}' and country = '{country}' and city='{city}' ;";
            
            MySqlCommand cmd = new MySqlCommand(query, conn);
            MySqlDataAdapter SQLAdapter = new MySqlDataAdapter(query,conn);

            DataTable DT = new DataTable();

            SQLAdapter.Fill(DT);

            donorsGridView.DataSource = DT;
            donorsGridView.DataBind();

            conn.Close();
        }

        protected void findBloodGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            blood_group = findBloodGroup.SelectedValue;
        }

        protected void findCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            country = findCountry.SelectedValue;
        }

        protected void findState_SelectedIndexChanged(object sender, EventArgs e)
        {
            state = findState.SelectedValue;
        }

        protected void findDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            district = findDistrict.SelectedValue;
        }

        protected void findCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            city = findCity.SelectedValue;
        }
    }
}