﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql;
using System.Diagnostics.Tracing;

namespace miniProject
{
    public partial class register : System.Web.UI.Page
    {
        public String blood_group;
        public String country;
        public String city;
        public String state;
        public String availability;
        public bool checkbox;
        public String district;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void registerSubmit_Click(object sender, EventArgs e)
        {
            String fullname = registerFullName.Text;
            
            String mobileNumber = registerMobileNumber.Text;
            String EmailId = registerEMail.Text;
            String UserId = registerUserId.Text;
            String password = registerPassword.Text;
            String RePassword = registerRePassword.Text;
            
            

            Response.Write($"<script>alert('{fullname},{blood_group},{mobileNumber},{country},{city},{state},{EmailId},{UserId},{password},{availability},{checkbox}');</script>");

            String connString = "host=localhost;username=root;password=Bhanu@123;database=exl_db";
            MySqlConnection conn = new MySqlConnection(connString);

            conn.Open();
            String query = $"insert into users values ('{fullname}','{blood_group}','{mobileNumber}','{country}','{city}','{state}','{EmailId}','{UserId}','{password}','{availability}','{checkbox}');";
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();

        }

        protected void registerCountryDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            country = registerCountryDropDown.SelectedValue;
        }

        protected void registerBloodGroupDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            blood_group=registerBloodGroupDropDown.SelectedValue;
        }

        protected void registerStateDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            state = registerStateDropDown.SelectedValue;
        }

        protected void registerDistrictDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            district =  registerDistrictDropDown.SelectedValue;
        }

        protected void registerCityDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            city = registerCityDropDown.SelectedValue; 
        }

        protected void registerAvailability_SelectedIndexChanged(object sender, EventArgs e)
        {
            availability  = registerAvailability.SelectedValue;
        }

        protected void registerAgreeCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            checkbox = registerAgreeCheckbox.Checked;
        }
    }
}